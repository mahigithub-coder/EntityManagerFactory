package com.cg.mts.service;

import java.time.LocalDateTime;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mts.entities.Activity;
import com.cg.mts.entities.Admin;

import com.cg.mts.repository.IActivityRepository;
import com.cg.mts.repository.IAdminRepository;
import com.cg.mts.repository.ICustomerRepository;



@Service
public class AdminService implements IAdminService {

	
	@Autowired
	IActivityRepository arepository;
	@Autowired
	IAdminRepository repository;
	@Autowired
	ICustomerRepository crepository;
	
	@Override
	public Admin insertAdmin(Admin admin) {
		
		return repository.save(admin);
	}

	@Override
	public Admin updateAdmin(Admin admin) {
		
		repository.save(admin);
		return admin;
	}

	@Override
	public Admin deleteAdmin(int adminId) {
		
		repository.deleteById(adminId);
		return null;
		
	}

	@Override
	public List<Activity> getAllActivities(int customerId) {
		  
		
		return null;
		 
		 }

	@Override
	public  List<Activity> getAllActivities() {
		return arepository.findAll();
		
		
	}

	@Override
	public List<Activity> getActivitiesCustomerwise() {
		
	 repository.findAll();
		return null;
		 
	}

	@Override
	public List<Activity> getActivitiesDatewise() {
		repository.findAll();
		return null;
	}

	@Override
	public List<Activity> getAllActivitiesForDays(int customerId, LocalDateTime fromDate, LocalDateTime toDate) {
		repository.findAll();
		return null;
	}

}
