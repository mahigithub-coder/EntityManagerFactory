package com.cg.mts.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.mts.entities.Activity;


@Repository
public interface IActivityRepository extends JpaRepository <Activity,Integer> {
	
	@Query(value = "select count(charges) FROM Activity where charges = ?1", nativeQuery = true)
	public int countActivitiesOfCharges(float charges);

	
}
