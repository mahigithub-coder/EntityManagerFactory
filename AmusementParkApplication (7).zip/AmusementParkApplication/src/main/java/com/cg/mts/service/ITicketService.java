package com.cg.mts.service;

import java.util.List;

import com.cg.mts.entities.Ticket;

public interface ITicketService {
	
	
	
	public Ticket insertTicket(Ticket ticket);
	public Ticket updateTicket(Ticket ticket);
	public Ticket deleteTicket(int ticketId);
	public List<Ticket> viewAllTicketsCustomer(int customerId);
	public Ticket calculateBill(int customerId);
	
	

}
