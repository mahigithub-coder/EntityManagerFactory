package com.cg.mts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mts.entities.Ticket;
import com.cg.mts.repository.ITicketRepository;

@Service
public class TicketService implements ITicketService{
	
	@Autowired
	ITicketRepository repository;


	

	@Override
	public Ticket insertTicket(Ticket ticket) {

		return repository.save(ticket);
	}

	@Override
	public Ticket updateTicket(Ticket ticket) {
		
		return repository.save(ticket);
	}

	@Override
	public Ticket deleteTicket(int ticketId) {
		
		return null;
	}

	@Override
	public List<Ticket> viewAllTicketsCustomer(int customerId) {
	
		return repository.findAll();
	}

	@Override
	public Ticket calculateBill(int customerId) {
	
		return null;
	}

}
