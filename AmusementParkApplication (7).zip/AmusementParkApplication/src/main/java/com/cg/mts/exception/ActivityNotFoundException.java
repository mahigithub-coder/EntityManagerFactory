package com.cg.mts.exception;

public class ActivityNotFoundException extends RuntimeException{
	
	

	public ActivityNotFoundException() {
		super();
		
	}

	public  ActivityNotFoundException(String message) {
		super(message);

}

}
