package com.cg.mts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mts.entities.Ticket;
import com.cg.mts.service.ITicketService;

@RestController
public class TicketController {
	
	@Autowired
	ITicketService service;
	
	
	@PostMapping("/ticket")
	public Ticket insertTicket(@RequestBody Ticket ticket) {

		return service.insertTicket(ticket);
	}

	@PutMapping("/ticket")
	public Ticket updateTicket(@RequestBody Ticket ticket) {

		return service.updateTicket(ticket);
	}

	@DeleteMapping("/ticket/{id}")
	public Ticket deleteTicket(@PathVariable int ticketId) {

		return service.deleteTicket(ticketId);
	}

	
	public List<Ticket> viewAllTicketsCustomer(int customerId) {

		return service.viewAllTicketsCustomer(customerId);
	}

	
	public Ticket calculateBill(int customerId) {

		return service.calculateBill(customerId);
	}

	
	

}
