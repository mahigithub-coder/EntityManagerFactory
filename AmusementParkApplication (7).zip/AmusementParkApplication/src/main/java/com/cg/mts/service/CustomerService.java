package com.cg.mts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mts.entities.Customer;
import com.cg.mts.repository.ICustomerRepository;

@Service
public class CustomerService implements ICustomerService{
	
	@Autowired
	ICustomerRepository repository;


@Override
public Customer insertCustomer(Customer customer) {
	
	return repository.save(customer);
}

@Override
public Customer updateCustomer(Customer customer) {

	return repository.save(customer);
}

@Override
public Customer deleteCustomer(int customerId) {
	
	repository.deleteById(customerId);
	return null;
}

@Override
public List<Customer> viewCustomers() {
	
	return repository.findAll();
}

@Override
public Customer viewCustomer(int customerId) {
	
	return repository.getById(customerId);
}

@Override
public Customer validateCustomer(String username, String password) {

	return repository.validateCustomer(username, password);
}
}
